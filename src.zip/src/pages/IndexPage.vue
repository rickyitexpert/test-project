<template>
  <q-page class="flex flex-center">
    <router-view></router-view>
  </q-page>
</template>

<script>
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'IndexPage'
})
</script>
